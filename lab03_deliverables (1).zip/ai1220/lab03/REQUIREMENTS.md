# CampusPulse requirements

Name or team: Makar Ulesov

Date: 2026-09-08

Status: reviewed draft, revised after validation

Use the source IDs `S1` to `S6` from the lab handout. Keep every requirement
short enough to test and trace.

## 1. Release scope

### In scope

List at least three capabilities that belong in the first release.

- University sign-in for students and staff, with verified group accounts that
  carry an official badge only after Student Affairs has checked the group. [S4, S6]
- Announcements and events published by groups, with a draft that one officer can
  start and another finish, publishing restricted to approved officers, and an
  audience of either the whole university or members only. [S2]
- Following groups, a single personal feed of everything from followed groups,
  and RSVP that is private by default. [S1, S5]
- Corrections to a published event, with a change notice to everyone holding an
  active RSVP. [S1, S2]
- Reporting content, a moderator hide action that keeps the evidence and records
  who decided, and a route for the group to appeal. [S3]

### Out of scope

List at least two explicit exclusions.

- Direct messages between people.
- Accounts for anyone outside the university, including alumni and the public.
- Payments and ticketing.
- Video hosting or upload.
- AI recommendation or ranking of the feed; the feed is reverse-chronological.
- Native mobile apps; the first release is a browser service only.

## 2. User requirements

Write at least five customer-readable needs. Use one need per line and trace it
to the stakeholder evidence.

Format: `UR-1 [Must] ... [Source: S1]`

- UR-1 [Must] A student can follow the groups they care about and see everything those groups post in one place, instead of checking email, Instagram and group chats. [Source: S1]
- UR-2 [Must] A student's RSVP stays private, and their name is shown to others only if that student chooses to show it. [Source: S1, S5]
- UR-3 [Must] Everyone who has RSVP'd is told when an event's time or place changes, or when it is cancelled. [Source: S2, S1]
- UR-4 [Must] Any officer of a group can start and edit a draft, but only officers the group has approved can publish in the group's name. [Source: S2]
- UR-5 [Must] A group can open an announcement or event to the whole university or keep it to its own members. [Source: S2]
- UR-6 [Must] Anyone can report content, a moderator can hide it straight away, and the evidence and the name of the person who decided are still there if the group appeals. [Source: S3]
- UR-7 [Must] The official badge appears only on groups Student Affairs has checked, so a student can tell a real group from an imitation. [Source: S4, S6]
- UR-8 [Must] The service collects only the personal data it needs, and attendance data for a cancelled event is removed within 30 days. [Source: S5]
- UR-9 [Should] A student can use the service on a phone browser and with a screen reader without needing a desktop computer. [Source: S1]
- UR-10 [Must] A group account that repeats the same announcement over and over is stopped and put in front of a moderator, so one stolen account cannot flood the feed. [Source: S6]
- UR-11 [Could] A student can put an event they have RSVP'd to into their own calendar. [Source: S1]

## 3. Functional requirements

Write at least six observable system behaviours. Start each one with "The
system shall" and trace it to one or more user requirements.

Format: `FR-1 [Must] The system shall ... [Source: UR-1]`

- FR-1 [Must] The system shall let a signed-in student follow and unfollow a group, and shall show the announcements and events of every group that student follows in one reverse-chronological feed. [Source: UR-1]
- FR-2 [Must] The system shall store every RSVP as private by default, and shall show an attendee's name to any account other than that attendee only after the attendee has turned on name sharing for that event. [Source: UR-2]
- FR-3 [Must] The system shall let any officer of a group save a draft announcement or event that another officer of the same group can open, edit and save. [Source: UR-4]
- FR-4 [Must] The system shall refuse a publish action from an account that is not an approved officer of the owning group, show the account the reason for the refusal, and record the attempt with the account, the group and the time. [Source: UR-4]
- FR-5 [Must] The system shall send a change notice to every account holding an active RSVP when an officer publishes a change to an event's start time, end time, location or cancellation status, and the notice shall state both the previous value and the new value. [Source: UR-3]
- FR-6 [Must] The system shall let the publishing officer set the audience of each announcement or event to "whole university" or "members only", and shall keep members-only items out of the feed, out of search results, and unreachable by direct link for any account that is not a member of that group. [Source: UR-5]
- FR-7 [Must] The system shall let any signed-in user report an announcement or event by choosing a reason from a fixed list and adding a free-text note, and shall store a copy of the reported content as it appeared when the report was made. [Source: UR-6]
- FR-8 [Must] The system shall let a moderator hide a reported item so that it is no longer visible to any account except moderators and the owning group's officers, while keeping the stored copy, the report, the moderator's identity and the decision time. [Source: UR-6]
- FR-9 [Must] The system shall show the official badge only on group profiles and posts of groups that Student Affairs has marked as verified, and shall stop showing it everywhere within the same session in which verification is withdrawn. [Source: UR-7]
- FR-10 [Must] The system shall delete the RSVP and attendance records of a cancelled event no later than 30 days after the cancellation, keeping only the number of attendees. [Source: UR-8]
- FR-11 [Should] The system shall refuse a publish action from a group account that has already published five announcements with identical text in the previous ten minutes, and shall raise a moderator alert naming that group. [Source: UR-10]
- FR-12 [Could] The system shall offer a downloadable calendar file for any event the signed-in user is allowed to see. [Source: UR-11]
- FR-13 [Should] The system shall let an approved officer of the owning group submit one appeal against a hide decision, and shall show a moderator the report, the stored copy of the content, and the appeal text in a single view. [Source: UR-6]

## 4. Non-functional requirements

Write at least four measurable quality requirements. State what is measured,
the target, and the condition under which the target applies. If you introduce
a number that is not in the handout, record it as an assumption or open
question in Section 8.

Format: `NFR-1 [Must] The system shall ... [Measure: target and condition] [Source: UR-1]`

- NFR-1 [Must] The system shall render the first screen of the personal feed quickly enough to be usable during Orientation Week. [Measure: 95th percentile time from request to first screen rendered is 2 seconds or less, measured in the browser on campus Wi-Fi with 500 signed-in users active at the same time] [Source: UR-1] [Assumption: A2, A3; see Q1]
- NFR-2 [Must] The system shall carry the pilot population without loss of function. [Measure: every functional acceptance test passes with 5,000 student accounts, 200 group accounts and 1,000 published items loaded] [Source: UR-1] [Source of the figures: S4]
- NFR-3 [Should] The system shall be operable with a screen reader on the sign-in, feed, event and RSVP pages. [Measure: zero WCAG 2.2 Level A or AA violations from an automated axe-core scan of those four pages, plus one manual pass of the follow-and-RSVP flow completed end to end with NVDA and with VoiceOver] [Source: UR-9] [Assumption: A4]
- NFR-4 [Must] The system shall be usable on a phone browser. [Measure: every page in scope is operable with no horizontal scrolling at a viewport width of 360 CSS pixels, and every interactive target is at least 24 by 24 CSS pixels, on the current release of Chrome for Android and Safari on iOS] [Source: UR-9] [Assumption: A5]
- NFR-5 [Must] The system shall keep moderation records separate from attendance data, so that the 30-day deletion of attendance data never removes the evidence behind a hide decision. [Measure: a moderation record - report, reason, stored copy, moderator identity, decision time - can still be retrieved 12 months after the decision date, and a run of the attendance deletion job leaves every such record intact] [Source: UR-6, UR-8] [Assumption: A6; see Q2, Q4]
- NFR-6 [Must] The system shall deliver change notices promptly. [Measure: for 99% of published changes over a calendar month, the notice appears in the recipient's in-app notifications and has been handed to the university mail service within 5 minutes of the change being published] [Source: UR-3] [Assumption: A7, A9]

## 5. User stories and acceptance criteria

Write at least three stories from different stakeholder viewpoints. Each story
needs at least two acceptance criteria. Across the set, include a failure,
permission boundary, privacy rule, or other non-happy path.

### US-1 [Source: S1, UR-2, UR-9]

As a student attendee,

I want my RSVP to stay private unless I say otherwise,

so that I can go to an event without my name appearing on a list other people can read.

Acceptance criteria:

- Given I have RSVP'd to an event and have not turned on name sharing, when another student opens that event page, then the page shows the number of attendees and does not show my name anywhere on the page or in the page source.
- Given I have turned name sharing on and then off again for an event, when another student reloads that event page, then my name is no longer shown.
- Given I open the event page with a screen reader, when I reach the RSVP control, then the control announces its current state as either "RSVP, not going" or "RSVP, going, name hidden" or "RSVP, going, name shown".

### US-2 [Source: S2, UR-4] - permission boundary and failure path

As a group officer,

I want a colleague to be able to start an announcement that I finish, while only approved officers can actually publish it,

so that we can share the drafting work without anyone posting in the group's name by mistake.

Acceptance criteria:

- Given officer A has saved a draft for group G, when officer B of the same group opens the drafts list, then the draft is listed and B can edit and save it.
- Given account C is a member of group G but is not an approved officer, when C presses Publish on a draft of group G, then the item is not published, C is shown the message that only approved officers of this group can publish, and a record of the attempt with C's account, group G and the time is written to the group's activity log.
- Given account C is not a member of group G at all, when C requests the draft by its direct URL, then the system returns a not-authorised response and no draft content.

### US-3 [Source: S1, S2, UR-3] - correction and delivery failure

As a student who has RSVP'd,

I want to be told when the time or place of an event changes,

so that I do not turn up at the wrong place or the wrong hour.

Acceptance criteria:

- Given I hold an active RSVP for an event, when an officer publishes a change to its start time, end time or location, then within 5 minutes I have an in-app notice that names the event and states both the old and the new value.
- Given an officer cancels the event, when the cancellation is published, then I receive a notice that says the event is cancelled, and the event page shows "Cancelled" rather than being deleted.
- Given the university mail service rejects or fails to accept a change notice, when the failure occurs, then the in-app notice is still shown, the failure is recorded against that notice, and delivery is retried at least twice within the following hour.

### US-4 [Source: S3, UR-6] - moderation with an evidence trail

As a campus moderator,

I want to hide a reported item immediately and still hold the evidence,

so that I can act fast on harm without losing what I need if the group appeals.

Acceptance criteria:

- Given a report exists on an event, when I open the report, then I see the reason chosen by the reporter, their free-text note, and a copy of the content as it stood when the report was made, even if the officer has edited the event since.
- Given I hide the item, when any student, including a follower of that group, opens the item or its direct link, then it is not shown, while moderators and the owning group's officers can still open it and see that it is hidden.
- Given I have hidden the item, when the moderation record is opened later, then it shows my account name and the date and time of the decision.

### US-5 [Source: S5, UR-8] - privacy rule

As the Data Protection Officer,

I want attendance data for cancelled events removed on a fixed schedule,

so that the service keeps only the personal data it still needs.

Acceptance criteria:

- Given an event was cancelled 31 days ago, when the retention job has run, then no RSVP or attendance row for that event holds a student identifier, and only the attendee count remains.
- Given an event was cancelled 3 days ago, when the retention job runs, then its RSVP rows are untouched.
- Given the cancelled event also has a moderation record, when the retention job has run, then the moderation record and its stored copy of the content are still retrievable.

### US-6 [Source: S4, S6, UR-7, UR-10] - abuse case

As Student Affairs,

I want the badge to appear only on groups we have checked, and repeated posting from one account to be stopped,

so that a phishing event or a stolen account cannot trade on the university's name.

Acceptance criteria:

- Given a group has not been marked as verified, when any student views its profile or any of its posts, then no official badge is shown anywhere on those pages.
- Given we withdraw verification from a group, when a student reloads that group's profile or an existing post within the same session, then the badge is gone.
- Given a group account has published five announcements with identical text in the last ten minutes, when it attempts a sixth, then the attempt is refused and an alert naming that group appears in the moderator queue.

## 6. MoSCoW summary

List requirement or story IDs in every category. The Won't category must state
what is excluded from this release.

- Must: UR-1, UR-2, UR-3, UR-4, UR-5, UR-6, UR-7, UR-8, UR-10; FR-1, FR-2, FR-3, FR-4, FR-5, FR-6, FR-7, FR-8, FR-9, FR-10; NFR-1, NFR-2, NFR-4, NFR-5, NFR-6; US-1, US-2, US-3, US-4, US-5, US-6.
- Should: UR-9; FR-11, FR-13; NFR-3. These ship in the first release if the Orientation Week date allows; if FR-13 slips, appeals are handled by email against the same stored evidence for the pilot only (see Conflict 3 in `stakeholders.md`).
- Could: UR-11; FR-12. Calendar download is wanted by students but nothing depends on it, and dropping it costs no other requirement.
- Won't this release: direct messages between people; accounts for anyone outside the university; payments and ticketing; video hosting or upload; AI recommendation or ranking of the feed; native mobile apps. These are exactly the exclusions listed in Section 1, and each is out because the handout places it outside the first release.

## 7. Traceability

Add at least four complete paths. Every row should connect evidence to a user
requirement, a system requirement, and a user story.

| Stakeholder need | User requirement | System requirement | User story |
|---|---|---|---|
| S1: "do not put my name on a public list unless I choose that" | UR-2 | FR-2 | US-1 |
| S2: "only approved officers should publish", one officer may start and another finish | UR-4 | FR-3, FR-4 | US-2 |
| S2: "if the place or time changes, tell the people who RSVP'd" | UR-3 | FR-5, NFR-6 | US-3 |
| S2: "some events are for the whole university and some are members-only" | UR-5 | FR-6 | US-2 |
| S3: report must show what and why; hide immediately; keep evidence for an appeal; record who decided | UR-6 | FR-7, FR-8, FR-13, NFR-5 | US-4 |
| S5: RSVP lists start private; delete attendance data within 30 days of cancellation | UR-8 | FR-10, NFR-5 | US-5 |
| S4 and S6: "an official badge must mean that we checked the group"; imitation of a verified group | UR-7 | FR-9 | US-6 |
| S6: a compromised account posting the same announcement repeatedly | UR-10 | FR-11 | US-6 |
| S1: "I normally use my phone; some students use screen readers" | UR-9 | NFR-3, NFR-4 | US-1 |
| S4: pilot of 5,000 students and 200 groups before Orientation Week | UR-1 | NFR-1, NFR-2 | US-3 |

## 8. Assumptions and open questions

Separate decisions your team has assumed from questions that still need an
answer.

### Assumptions

- A1: An "approved officer" is a role Student Affairs grants to the group's president when it verifies the group, and the president may then approve further officers of the same group. No stakeholder said how officers are approved.
- A2: 500 signed-in users active at the same time is our own working figure for Orientation Week peak. The brief gives no peak traffic figure.
- A3: The 2-second first-screen target in NFR-1 is ours; no stakeholder gave a speed target.
- A4: WCAG 2.2 Level AA is our chosen standard. S1 mentioned screen readers but named no standard, so the standard is our decision, not theirs.
- A5: 360 CSS pixels is our chosen minimum phone width, and 24 by 24 CSS pixels our minimum target size. Neither figure comes from a stakeholder.
- A6: 12 months is our chosen retention period for moderation records. Neither S3 nor S5 gave one.
- A7: Change notices are delivered by university email and by an in-app notice. No stakeholder named a channel, and the service has no push channel without a native app.
- A8: A "member" of a group is an account that the group's officers have added to its member list; there is no self-service joining in this release.
- A9: The 5-minute, 99% target in NFR-6 is ours. S2 asked to be able to tell people, but gave no timing.

### Open questions

- Q1: What peak concurrent use should we design for during Orientation Week? Until S4 answers, NFR-1 rests on our own figure of 500 (A2).
- Q2: If a hide decision is still under appeal on day 30 after a cancellation, does the attendance data still go, and is an attendee count enough for the appeal? (S3 and S5, Conflict 1.)
- Q3: For members-only events, where the group already holds the membership list, may officers see attendee names by default, or must name sharing stay opt-in there too? (S1, S2, S5, Conflict 2.)
- Q4: How long must moderation records be kept after an appeal closes, and who may read them then? Our 12 months (A6) is a placeholder until S3 and S5 agree a period.
- Q5: Who can withdraw a group's badge, and does that group's already-published content stay visible afterwards? (S4 and S3.)
- Q6: How long should the log of refused publish attempts in FR-4 be kept? It names an account and a time, so it is personal data. (S5.)
- Q7: Do you accept appeals being handled by email during the pilot if FR-13 slips, or is an in-product appeal a condition of going live? (S4, Conflict 3.)

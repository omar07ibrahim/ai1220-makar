# CampusPulse stakeholder analysis

Name or team: Makar Ulesov

Date: 2026-09-08

Read the stakeholder notes in the lab handout before completing this file.
Use the stakeholder types and power-interest quadrants from Week 2, Lecture 2.

Stakeholder types: end user, operations, business, regulator, negative stakeholder

Power-interest quadrants: key player, keep satisfied, keep informed, minimal effort

## S1

- Stakeholder: Student attendee. Follows several clubs, uses a phone browser, and
  some students in this group use screen readers.
- Stakeholder type: end user
- Power-interest quadrant: keep informed. Interest is high because this group uses
  the service daily, but no single student can stop the pilot. The group as a whole
  decides whether the service is adopted, so it must be kept informed and listened
  to even though it holds little formal power.
- Main goal: see everything from the clubs they follow in one place, instead of
  checking email, Instagram, and group chats separately.
- Main concern: their name appearing on a public RSVP list without them choosing
  it, and the service being awkward on a phone or with a screen reader.
- How you would involve or monitor this stakeholder: recruit 8-10 students,
  including at least two screen-reader users, for a walkthrough of the feed and the
  RSVP flow before the pilot; keep a feedback link in the footer during the pilot
  and review it weekly with S4.

## S2

- Stakeholder: Group officer. Drafts and publishes announcements and events on
  behalf of a student group.
- Stakeholder type: end user (also acts as day-to-day content operations for the group)
- Power-interest quadrant: key player. High interest because officers use the
  service to do their job, and high power because without groups posting there is
  nothing in the feed and the pilot fails.
- Main goal: let one officer start an announcement and another finish it, publish
  to the right audience (whole university or members only), and keep people who
  have RSVP'd up to date when an event moves.
- Main concern: an unapproved account publishing in the group's name, and
  attendees turning up at the old place or time after a change.
- How you would involve or monitor this stakeholder: run a workshop with officers
  from 6-8 groups covering the draft handoff and the publish permission; give them
  a pre-pilot sandbox group; track how many publish attempts are rejected (FR-4)
  as a sign that the officer approval model is wrong.

## S3

- Stakeholder: Campus moderator. Reviews reports and decides whether content is
  hidden.
- Stakeholder type: operations
- Power-interest quadrant: key player. High interest because the moderation queue
  is their daily work, and high power because an unusable moderation and appeal
  process would stop Student Affairs approving the pilot.
- Main goal: see what was reported and why, hide harmful content immediately, and
  still hold the evidence if the group appeals, with a record of who decided.
- Main concern: evidence being lost - either by an officer editing or deleting the
  content after a report, or by a data-deletion job removing the record before the
  appeal is settled.
- How you would involve or monitor this stakeholder: review the report reasons and
  the moderator screens with them before the build; agree the retention period for
  moderation records with them and S5 together; during the pilot, review the queue
  weekly for reports that were never actioned.

## S4

- Stakeholder: Student Affairs. Sponsors the service, owns the official badge, and
  sets the pilot target of 5,000 students and 200 groups before Orientation Week.
- Stakeholder type: business
- Power-interest quadrant: keep satisfied. Very high power - they fund the pilot,
  own the verification decision, and can stop the release - but their interest is
  in the outcome and the university's reputation rather than in weekly feature
  detail.
- Main goal: a service that is ready for Orientation Week and in which the official
  badge is a promise the university has actually checked the group.
- Main concern: the badge being trusted and then misused, and the pilot missing the
  Orientation Week date.
- How you would involve or monitor this stakeholder: a short fortnightly written
  update against the pilot scope rather than a standing meeting; escalate any
  change to scope, the badge rules, or the pilot date to them for a decision; ask
  them for the peak-traffic figure that the brief does not give (Q1).

## S5

- Stakeholder: Data Protection Officer.
- Stakeholder type: regulator
- Power-interest quadrant: keep satisfied. High power because they can block the
  release over a data protection failing, but low day-to-day interest in the
  product itself; they care about the data rules being followed.
- Main goal: the service collects only the personal data it needs, RSVP lists start
  private, and attendance data for a cancelled event is deleted within 30 days.
- Main concern: personal data being kept longer than needed or exposed by default,
  particularly through RSVP lists and through moderation evidence.
- How you would involve or monitor this stakeholder: submit a one-page data
  inventory (what is stored, why, and for how long) for sign-off before the pilot;
  book a single review to settle the conflict between the 30-day deletion rule and
  moderation evidence retention (Conflict 1); report any data incident to them
  within one working day.

## S6

- Stakeholder: Abuse cases - an impersonator who imitates a verified group to
  publish a phishing event, and a compromised group account that posts the same
  announcement repeatedly.
- Stakeholder type: negative stakeholder
- Power-interest quadrant: minimal effort for involvement, but active monitoring.
  They are never consulted or involved, and their interest is in the service
  failing. Their power over the university's trust in the badge is real, so the
  effort goes into detection and rate limits (FR-9, FR-11) rather than engagement.
- Main goal: get students to trust a false event or flood the feed from a stolen
  account.
- Main concern (ours, about them): a phishing event carrying an official badge, and
  a single compromised account making the feed unusable.
- How you would involve or monitor this stakeholder: do not involve. Monitor
  instead - alert a moderator when a group account repeats identical text (FR-11),
  make the badge removable the moment verification is withdrawn (FR-9), and review
  reports tagged "impersonation" weekly with S3.

## Conflicts to resolve

Describe at least two real tensions. For each one, name both stakeholder IDs
and either propose a decision or write a specific question that should go back
to the stakeholders.

### Conflict 1

- Stakeholders: S3 (campus moderator) and S5 (Data Protection Officer)
- What conflicts: S3 must keep the evidence behind a hide decision so that a group
  can appeal, and needs a record of who decided. S5 requires data minimisation and
  the deletion of attendance data within 30 days of a cancellation. A hidden event
  that is then cancelled sits in both rules at once: the moderation case still needs
  its evidence, and the attendance data must go.
- Proposed decision or follow-up question: separate the two record types. A
  moderation record holds the report, the reason, a stored copy of the content as
  published, and the moderator's identity and decision time; it holds no attendee
  identities, only a count. Attendance records are deleted on the 30-day rule
  regardless of the moderation case (FR-10, NFR-5). Question still to ask S5 and
  S3 together: "If an appeal is still open on day 30 after a cancellation, does the
  attendance data go anyway, and is an attendee count enough for the appeal?" (Q2)

### Conflict 2

- Stakeholders: S1 (student attendee) and S2 (group officer)
- What conflicts: S1 does not want their name on a list unless they choose it, and
  S5 backs this by requiring RSVP lists to start private. S2 runs members-only
  events and needs to plan for numbers, which in practice means officers wanting to
  see who is coming.
- Proposed decision or follow-up question: for this release, RSVP is private by
  default; officers always see an attendee count, and see a name only when that
  attendee has turned on name sharing for that event (UR-2, FR-2). Question to put
  to S1, S2 and S5: "For members-only events, where the group already holds the
  membership list, may officers see attendee names by default, or must sharing stay
  opt-in there too?" (Q3)

### Conflict 3

- Stakeholders: S4 (Student Affairs) and S3 (campus moderator) with S5
- What conflicts: S4 has fixed the pilot to Orientation Week with 5,000 students
  and 200 groups. The moderation, appeal, and retention work that S3 and S5 need is
  not small, and doing all of it well competes directly with that date.
- Proposed decision or follow-up question: hold the date and cut elsewhere. The
  hide action, the evidence store, and the decision log ship in the first release
  because they are what makes moderation defensible (FR-7, FR-8, NFR-5); the appeal
  is a Should (FR-13) and, if it slips, appeals are handled by email against the
  same stored evidence for the pilot only. Question for S4: "Do you accept appeals
  being handled by email during the pilot, or is an in-product appeal a condition of
  going live?"

# CampusPulse requirements review

Name or team: Makar Ulesov

Reviewer: Makar Ulesov, reviewing the draft against the five Lecture 2 checks

Date: 2026-09-08

Review the completed `stakeholders.md` and `REQUIREMENTS.md`. Refer to specific
IDs and evidence in every answer. A yes or no by itself is not enough.

## Validity

Do the requirements represent what the stakeholders need? Which IDs did you
check, and what evidence supports them?

Response:

I checked each Must user requirement back against the exact wording in the source
notes.

- UR-2 and FR-2 match S1's "do not put my name on a public list unless I choose
  that" and S5's "RSVP lists should start private". Both sources point the same
  way, so private-by-default with an opt-in is a fair reading of the evidence.
- UR-4 and FR-3/FR-4 match S2's "one officer may start an announcement and another
  finish it, but only approved officers should publish". The draft-handoff half was
  easy to lose, so it is written as its own requirement (FR-3) rather than being
  folded into the publish rule.
- UR-6, FR-7, FR-8 and NFR-5 cover all three things S3 asked for: what was reported
  and why, hiding immediately, and keeping the evidence with a record of who
  decided. FR-8 names the moderator's identity and decision time explicitly because
  S3 said "we also need a record of who made the decision".
- UR-8 and FR-10 restate S5's 30-day rule without softening it.
- UR-7 and FR-9 come from S4's "an official badge must mean that we checked the
  group" together with the S6 impersonation case; the badge is therefore tied to a
  verification flag rather than to anything the group can set itself.

Two places go beyond the evidence and are marked as such. NFR-1 uses a 2-second
target and 500 concurrent users, and the brief explicitly gives no peak traffic
figure - these are recorded as A2 and A3 with Q1 open to S4. NFR-3 names WCAG 2.2
AA, which S1 never mentioned; that is A4. Neither is presented as a stakeholder
figure.

One requirement is weaker than the rest on validity: UR-9. S1 said "I normally use
my phone; some students use screen readers", which is a statement of how they work,
not a stated need for a particular standard. UR-9 is kept as a Should for that
reason, with the testable detail pushed into NFR-3 and NFR-4.

## Consistency

Do any requirements contradict one another or the release scope?

Response:

- Scope against MoSCoW: the six exclusions in Section 1 (direct messages, external
  users, payments, video hosting, AI recommendations, native apps) are the same six
  items in the Won't list, worded the same way. No item appears in both lists.
- FR-10 against NFR-5: this was a real contradiction at first. FR-10 deletes
  attendance data 30 days after a cancellation, while S3 needs the evidence behind
  a hide decision to survive for an appeal. If the moderation record had held
  attendee identities, the two requirements would have pulled against each other.
  NFR-5 now separates the two record types, and FR-10 keeps only a count. This is
  Conflict 1 in `stakeholders.md`, and Q2 is still open with S5 and S3 about what
  happens when an appeal is still open on day 30.
- UR-2 against UR-5: members-only events (UR-5) do not override private RSVP
  (UR-2). The decision for this release is that officers see a count and only
  opt-in names, in either audience. It is a decision rather than something the
  stakeholders settled, so Q3 is open.
- FR-9 against the scope: FR-9 says the badge disappears "within the same session"
  when verification is withdrawn, but nothing in the document says who may withdraw
  it. That gap is Q5 rather than a contradiction.
- FR-11 against UR-1: rate-limiting a group account (FR-11) could in principle block
  a legitimate burst of posts. Five identical posts in ten minutes is narrow enough
  that a group posting five different announcements is unaffected, so the two do not
  conflict as written.

## Completeness

Is an important actor, normal flow, failure, permission, privacy rule, or
boundary missing?

Response:

Three gaps were found by walking each source note against the requirement list.

1. **The appeal had no requirement.** S3 says "I still need the evidence if the
   group appeals", and FR-8 kept the evidence, but nothing in the draft let a group
   actually appeal or let a moderator see the appeal beside the evidence. FR-13 was
   added for this, as a Should, and the traceability row for S3 now shows FR-13.
2. **Delivery failure of a change notice.** The draft assumed the notice arrives.
   US-3 now has a third acceptance criterion covering the case where the mail
   service rejects the notice: the in-app notice still shows, the failure is
   recorded, and delivery is retried.
3. **The verification actor.** Student Affairs is named as the source of the badge
   but is not an actor anywhere in Section 3 - no requirement describes granting or
   withdrawing verification. This is left as Q5 rather than invented, because it is
   a policy decision for S4.

Covered and checked as present: the permission boundary (FR-4, US-2 including the
direct-URL case), the privacy rule (FR-2, FR-10, US-1, US-5), the abuse cases from
S6 (FR-9, FR-11, US-6), and the members-only boundary including direct links
(FR-6).

Still thin: what happens to a group's published content when the group is removed
or its verification withdrawn (Q5), and the retention period for the refused-publish
log in FR-4, which is itself personal data (Q6).

## Realism

Can the proposed release and its quality targets reasonably be delivered? Mark
unsupported targets as assumptions or open questions.

Response:

- NFR-2 is realistic and is the only NFR whose numbers come from a stakeholder:
  5,000 students and 200 groups are S4's figures. A pilot at that size is a
  moderate load for a browser service with a reverse-chronological feed and no
  ranking.
- NFR-1 is the least safe. The 2-second, 95th-percentile target at 500 concurrent
  users is entirely ours (A2, A3), and Orientation Week is exactly when the real
  peak is unknown. Q1 asks S4 for a figure; until it is answered, NFR-1 should be
  read as a design target and not a commitment.
- NFR-6 is deliverable for the in-app half but only partly under our control for
  email: once a notice is handed to the university mail service, the delivery time
  is theirs. The measure is therefore written as "handed to the mail service and
  shown in-app within 5 minutes", which is something we can actually meet and test.
- NFR-3 is a Should rather than a Must for schedule reasons. A full WCAG 2.2 AA
  pass across the whole product before Orientation Week is not realistic, so the
  requirement is scoped to four pages and one flow.
- Scope realism overall: FR-13 (appeal) is the item most likely to slip, which is
  Conflict 3 in `stakeholders.md`, with the email fallback and Q7 recorded rather
  than assumed.

## Verifiability

Could a tester decide whether each requirement passes or fails? Identify any
wording that is still vague.

Response:

Most requirements pass this check because they name an observable result: FR-2
names what another account sees, FR-4 names the refusal and the log entry, FR-6
names feed, search and direct link, FR-10 names what is left after deletion.

Wording that failed the check and was fixed:

- FR-5 was "The system shall notify people who RSVP'd when an event changes". A
  tester cannot decide this: "changes" is undefined, "notify" names no channel and
  no content, and there is no time limit. It is revised below.

Wording that is still soft, and why it is being left:

- UR-1, UR-9 and the other URs use plain language on purpose - they are meant for a
  customer to read, and their testable form lives in the FRs and NFRs they trace to.
  UR-9's "without needing a desktop computer" is not testable by itself, but NFR-3
  and NFR-4 are.
- FR-9's "within the same session" is testable but coarse; a tester should read it
  as "on the next page load after withdrawal", which is how US-6's second criterion
  words it.
- NFR-5's "retrievable" needs a named person or role to do the retrieving before it
  can be run as a test. That depends on Q4.

## One requirement you revised

- Requirement ID: FR-5 (with a new NFR-6 carrying the timing)
- Before: `FR-5 [Must] The system shall notify people who RSVP'd when an event
  changes. [Source: UR-3]`
- What was wrong or missing: three things. "Changes" was undefined, so a tester
  could not tell whether fixing a typo in the description should trigger a notice.
  "Notify" named no channel and no content, so a notice saying only "this event was
  updated" would have passed while leaving the attendee no better off - and S2's
  actual worry is people arriving at the old place or time. And there was no
  timing, so a notice sent the following week would also have passed. The
  requirement also mixed a behaviour with an unstated performance expectation,
  which belongs in an NFR.
- After: `FR-5 [Must] The system shall send a change notice to every account
  holding an active RSVP when an officer publishes a change to an event's start
  time, end time, location or cancellation status, and the notice shall state both
  the previous value and the new value. [Source: UR-3]` plus `NFR-6 [Must] The
  system shall deliver change notices promptly. [Measure: for 99% of published
  changes over a calendar month, the notice appears in the recipient's in-app
  notifications and has been handed to the university mail service within 5 minutes
  of the change being published] [Source: UR-3] [Assumption: A7, A9]`
- Evidence or stakeholder to confirm the change: S2 - "if the place or time
  changes, tell the people who RSVP'd" - supports the four named fields and the
  old-and-new wording. Two things in the revision are ours and not S2's: the 5
  minutes and 99% (recorded as A9) and the email plus in-app channels (A7). Both
  should be put to S2, along with whether cancellation counts as a change worth
  notifying, which we have assumed that it does. US-3 was updated to match, and the
  traceability row for S2's change note now reads UR-3 -> FR-5, NFR-6 -> US-3.

## Final check

- [x] Stakeholder conflicts have a decision or a follow-up question.
- [x] Scope exclusions agree with the Won't list.
- [x] Every FR and NFR traces to a user requirement.
- [x] Every NFR contains a measurable target and condition.
- [x] Traceability rows use IDs that exist in the document.
- [x] The revised requirement has also been updated in the traceability table.
